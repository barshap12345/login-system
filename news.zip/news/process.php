<?php



$mysqli = new mysqli('localhost','root','','crud') or die(mysqli_error($mysqli));

$id = 0;
$update = false;
$subject = '';
$semester = '';

if (isset($_POST['save'])){
	$subject = $_POST['subject'];
	$semester = $_POST['semester'];
	
	$mysqli->query("INSERT INTO data (subject, semester) VALUES('$subject', '$semester')") or die($mysqli->error);
	$_SESSION['message'] = "Record has been saved!";
	$_SESSION['msg_type'] = "success";
	
	header("location: home.php");
}

if (isset($_GET['delete'])){
	$id = $_GET['delete'];
	$mysqli->query("DELETE FROM data WHERE id=$id") or die($mysqli->error());
	
	
	$_SESSION['message'] = "Record has been deleted!";
	$_SESSION['msg_type'] = "danger";
	
		header("location: home.php");

}
if (isset($_GET['edit'])){
	$id = $_GET['edit'];
	$update = true;
	$result = $mysqli->query("SELECT * FROM data WHERE id=$id") or die($mysqli->error());
	if (count($result)==1){
		$row = $result->fetch_array();
		$subject = $row['subject'];
		$semester = $row['semester'];
	}
}
if (isset($_POST['update'])){
	$id = $_POST['id'];
	$subject = $_POST['subject'];
	$semester = $_POST['semester'];
	
	$mysqli->query("UPDATE data SET subject='$subject', semester='$semester' WHERE id=$id") or
		die($mysqli->error);
		
	$_SESSION['message'] = "record has been updated!";
	$_SESSION['msg_type'] = "warning";
	
	header('location: home.php');
	
}

?>
