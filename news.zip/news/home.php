<?php 

session_start();
if(!isset($_SESSION['username'])){
	header('location:login.php');
}
 
?>

<html>
<head>
<title> home page </title>
	<link rel="stylesheet" type="text/css" href="style.css">
	<link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
	
</head>
<body>
<div>
		<div>
		<h1 width=75%> welcome <?php echo $_SESSION['username']; ?> </h1>
		</div>
		
		<div style="float: right;" align="center">
		<a  href = "logout.php" width=25% > LOGOUT </a>
		</div>
</div>

	<?php require_once'process.php'; ?>
	
	<?php 
	
	if (isset($_SESSION['message'])): ?>
	
	<div class="alert alert-<?=$_SESSION['msg_type']?>">
	
	<?php 
		echo $_SESSION['message'];
		unset($_SESSION['message']);
	?>
	</div>
	
	<?php endif ?>
	
	
	<div class="container">
	
		
		
			<div class="row">
	
	<?php
		$mysqli = new mysqli('localhost','root','','crud') or die(mysqli_error($mysqli));
		$result = $mysqli->query("SELECT * FROM data") or die($mysqli->error);
		//pre_r($result);
		?>
		
		
		
		<div class="col-md-6 login-left">
			<table class="table">
				<thead>
					<tr>
						<th> subject </th>
						<th> semester </th>
						<th colspan="2">Action</th>
					</tr>
				</thead>
		<?php 
			while($row = $result->fetch_assoc()): ?>
			<tr> 
				<td><?php echo $row['subject']; ?></td>
				<td><?php echo $row['semester']; ?></td>
				<td> 
					<a href="home.php?edit=<?php echo $row['id']; ?>"
						class="btn btn-info">Edit</a>
					<a href="process.php?delete=<?php echo $row['id']; ?>"
						class="btn btn-danger">Delete</a>
				</td>
			</tr>
			<?php endwhile;?>
			</table>
	
		</div>
		
		
		<?php
		
		function pre_r($array){
			echo'<pre>';
			print_r($array);
			echo'</pre>';
		}
	?>	
	
	
	
	
	<div class="col-md-6 login-left">
	<form action="process.php" method="POST">
	
		<input type="hidden" name="id" value="<?php echo $id;?>">
	
		<div class="form-group">
			<label>subject</label>
			<input type="text" name="subject" class="form-control" value="<?php echo $subject; ?>"  required>
		</div>
		
		<div class="form-group">
			<label>semester</label>
			<input type="text" name="semester" class="form-control" value="<?php echo $semester; ?>" required>
		</div> 
		
		
		<div class="form-group">
		
		<?php
		if ($update == true):
		?>
		<button type="submit" class="btn btn-info" name="update"> update </button>
		
		<?php else: ?>
			<button type="submit" class="btn btn-primary" name="save"> save </button>
		<?php endif; ?>
		</div>
		</form>
	</div>
	</div>
	</div>
	</div>
</body>
</html>